/**Main App Orchestrator & Views Renderer */
window.ContentOS = window.ContentOS || {};
(function (App) {
  'use strict';

  var editingPostId = null;

  App.main = {
    init: function () {
      this.initTheme();
    },

    initTheme: function () {
      var savedTheme = App.storage.get('contentos:theme', 'dark');
      document.body.setAttribute('data-theme', savedTheme);
    },

    toggleTheme: function () {
      var currentTheme = document.body.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      var nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
      document.body.setAttribute('data-theme', nextTheme);
      App.storage.set('contentos:theme', nextTheme);
      var btns = document.querySelectorAll('.theme-toggle-btn');
      for (var i = 0; i < btns.length; i++) {
        btns[i].textContent = nextTheme === 'dark' ? 'Light' : 'Dark';
      }
    },

    renderAppShell: function (pageName, appEl) {
      if (!appEl) return;
      this.initTheme();

      var session = App.auth ? App.auth.getSession() : null;
      var profile = session ? App.storage.get(App.storage.getUserKey('contentos:profile'), null) : null;
      var currentTheme = document.body.getAttribute('data-theme') || 'dark';

      appEl.innerHTML =
        '<header class="app-header">' +
          '<div class="header-brand">' +
            '<span class="logo-badge">C</span>' +
            '<span class="logo-title">ContentOS</span>' +
          '</div>' +
          '<nav class="app-nav">' +
            '<a href="dashboard.html" class="nav-link' + (pageName === 'dashboard' ? ' active' : '') + '">Dashboard</a>' +
            '<a href="posts.html" class="nav-link' + (pageName === 'posts' ? ' active' : '') + '">Post Log</a>' +
            '<a href="ideas.html" class="nav-link' + (pageName === 'ideas' ? ' active' : '') + '">Ideas</a>' +
          '</nav>' +
          '<div class="header-user">' +
            '<span class="user-pill">@' + (session ? session.handle : 'creator') + ' (' + (profile ? profile.niche : 'Creator') + ')</span>' +
            '<button id="themeToggleBtn" class="theme-toggle-btn" title="Toggle Theme">' + (currentTheme === 'dark' ? 'Light' : 'Dark') + '</button>' +
            '<button id="logoutBtn" class="btn btn-secondary btn-sm">Log Out</button>' +
          '</div>' +
        '</header>' +
        '<main class="app-body" id="viewContainer"></main>';

      var themeToggleBtn = document.getElementById('themeToggleBtn');
      if (themeToggleBtn) {
        var self = this;
        themeToggleBtn.addEventListener('click', function () {
          self.toggleTheme();
        });
      }

      var logoutBtn = document.getElementById('logoutBtn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
          if (App.auth) App.auth.logout();
        });
      }

      var container = document.getElementById('viewContainer');
      if (!container) return;

      if (pageName === 'dashboard') {
        this.renderDashboardView(container);
      } else if (pageName === 'posts') {
        this.renderPostsView(container);
      } else if (pageName === 'ideas') {
        this.renderIdeasView(container);
      }
    },

    // 1. LOGIN VIEW
    renderLoginView: function (container) {
      this.initTheme();
      var self = this;
      var currentTheme = document.body.getAttribute('data-theme') || 'dark';
      var mode = 'login'; // default mode

      var renderForm = function () {
        container.innerHTML =
          '<div class="auth-wrapper">' +
            '<div class="auth-card">' +
              '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">' +
                '<div class="auth-mode-toggle">' +
                  '<button type="button" id="tabLoginBtn" class="auth-tab-btn ' + (mode === 'login' ? 'active' : '') + '">Login</button>' +
                  '<button type="button" id="tabRegisterBtn" class="auth-tab-btn ' + (mode === 'register' ? 'active' : '') + '">Register</button>' +
                '</div>' +
                '<button id="loginThemeToggleBtn" class="theme-toggle-btn">' + (currentTheme === 'dark' ? 'Light' : 'Dark') + '</button>' +
              '</div>' +

              '<div class="auth-brand">' +
                '<span class="logo-badge large">C</span>' +
                '<h1 class="auth-title">ContentOS</h1>' +
                '<p class="auth-subtitle">' + (mode === 'login' ? 'Sign in to access your creator workspace.' : 'Create a creator account and set your followers.') + '</p>' +
              '</div>' +

              '<form id="loginForm" novalidate>' +
                '<div class="form-group">' +
                  '<label class="form-label" for="handleInput">Creator Handle *</label>' +
                  '<div class="input-prefix-wrapper">' +
                    '<span class="prefix">@</span>' +
                    '<input type="text" id="handleInput" class="form-input" placeholder="username" />' +
                  '</div>' +
                '</div>' +

                (mode === 'register' ?
                  '<div class="form-group">' +
                    '<label class="form-label" for="nicheSelect">Creator Niche *</label>' +
                    '<select id="nicheSelect" class="form-select">' +
                      '<option value="Tech">Tech</option>' +
                      '<option value="Fitness">Fitness</option>' +
                      '<option value="Food">Food</option>' +
                      '<option value="Lifestyle" selected>Lifestyle</option>' +
                      '<option value="Fashion">Fashion</option>' +
                      '<option value="Education">Education</option>' +
                    '</select>' +
                  '</div>' +
                  '<div class="form-group">' +
                    '<label class="form-label" for="followersInput">Current Total Followers *</label>' +
                    '<input type="number" id="followersInput" class="form-input" min="1" placeholder="e.g. 5000" />' +
                    '<div style="font-size:11px; color:var(--text-dim); margin-top:4px;">Enter your current follower count for accurate reach calculations.</div>' +
                  '</div>'
                  : ''
                ) +

                '<div class="form-group">' +
                  '<label class="form-label" for="passInput">Password *</label>' +
                  '<input type="password" id="passInput" class="form-input" placeholder="' + (mode === 'login' ? 'Enter password' : 'Create password (min 4 chars)') + '" />' +
                '</div>' +

                '<div id="handleError" class="form-error" style="margin-bottom:12px;"></div>' +
                '<button type="submit" class="btn btn-primary btn-full">' + (mode === 'login' ? 'Login & Enter Workspace' : 'Create Account & Enter') + '</button>' +
              '</form>' +
            '</div>' +
          '</div>';

        // Attach event listeners
        var tabLoginBtn = document.getElementById('tabLoginBtn');
        var tabRegisterBtn = document.getElementById('tabRegisterBtn');

        if (tabLoginBtn) {
          tabLoginBtn.addEventListener('click', function () {
            if (mode !== 'login') {
              mode = 'login';
              renderForm();
            }
          });
        }

        if (tabRegisterBtn) {
          tabRegisterBtn.addEventListener('click', function () {
            if (mode !== 'register') {
              mode = 'register';
              renderForm();
            }
          });
        }

        var loginThemeToggleBtn = document.getElementById('loginThemeToggleBtn');
        if (loginThemeToggleBtn) {
          loginThemeToggleBtn.addEventListener('click', function () {
            self.toggleTheme();
            currentTheme = document.body.getAttribute('data-theme');
            renderForm();
          });
        }

        var form = document.getElementById('loginForm');
        var handleInput = document.getElementById('handleInput');
        var passInput = document.getElementById('passInput');
        var handleError = document.getElementById('handleError');

        form.addEventListener('submit', function (e) {
          e.preventDefault();

          var handleVal = handleInput ? handleInput.value : '';
          var passVal = passInput ? passInput.value : '';

          var authRes;
          if (mode === 'login') {
            authRes = App.auth.login(handleVal, passVal);
          } else {
            var nicheEl = document.getElementById('nicheSelect');
            var nicheVal = nicheEl ? nicheEl.value : 'Lifestyle';
            var followersEl = document.getElementById('followersInput');
            var followersVal = followersEl ? followersEl.value : '';
            authRes = App.auth.register(handleVal, passVal, nicheVal, followersVal);
          }

          if (!authRes.success) {
            handleError.textContent = authRes.error;
            handleError.style.display = 'block';
            return;
          }

          handleError.style.display = 'none';
          window.location.href = 'dashboard.html';
        });
      };

      renderForm();
    },

    // 2. DASHBOARD VIEW
    renderDashboardView: function (container) {
      var self = this;
      var posts = App.postsStore.getAll();
      var stats = App.recommendations.getStats(posts);

      var rawFollowers = App.followersStore ? App.followersStore.getLatestFollowers() : null;
      var followers = rawFollowers !== null ? rawFollowers : 10000;
      var isFollowersSet = rawFollowers !== null;
      var currentMonthKey = App.followersStore ? App.followersStore.getCurrentMonthKey() : 'Aug 2026';

      var igData = {
        followersCount: followers,
        followersMonth: currentMonthKey
      };

      var indulgence = App.indulgenceEngine.calculateIndulgence(igData, posts);
      var weeklyPredictions = App.analyticsEngine.getWeeklyDayPredictions(posts);

      // Build 7-Day Day-of-Week Prediction Cards HTML
      var weeklyGridHtml = '';
      for (var w = 0; w < weeklyPredictions.length; w++) {
        var wp = weeklyPredictions[w];
        weeklyGridHtml +=
          '<div class="day-pred-card">' +
            '<div class="day-pred-header">' +
              '<span class="day-name">' + wp.day + '</span>' +
              '<span class="day-score-pill">Score: ' + wp.viralScore + '</span>' +
            '</div>' +
            '<div class="day-best-time">Best Time: ' + wp.bestTime + '</div>' +
            '<div class="day-niche-tag">Niche: <strong>' + wp.bestTopic + '</strong></div>' +
            '<div class="day-format-tag">Format: <span class="badge badge-reel">' + wp.bestFormat + '</span></div>' +
            '<div class="day-est-reach">Est. Reach: ~' + wp.avgReach.toLocaleString() + '</div>' +
            '<div class="day-hook-box">' + wp.suggestedHook + '</div>' +
          '</div>';
      }

      // Build SVG Charts
      var trendChartSvg = App.analyticsEngine.renderPerformanceTrendChart(posts);
      var formatChartSvg = App.analyticsEngine.renderFormatEfficiencyChart(posts);

      // Default Prediction for Predictor Widget
      var initialPred = App.analyticsEngine.predictPostPerformance('10 Minimalist Desk Setup Items That Doubled My Focus', 'Reel', 'Productivity Systems');

      // Build Niche Breakdown HTML
      var nicheHtml = '';
      if (indulgence.nicheBreakdown) {
        for (var nicheName in indulgence.nicheBreakdown) {
          var pct = indulgence.nicheBreakdown[nicheName];
          nicheHtml +=
            '<div class="indulgence-bar-group">' +
              '<div class="indulgence-bar-label"><span>' + nicheName + '</span><span>' + pct + '%</span></div>' +
              '<div class="indulgence-bar-track"><div class="indulgence-bar-fill" style="width:' + pct + '%;"></div></div>' +
            '</div>';
        }
      }

      // Build Format Craving HTML
      var formatHtml = '';
      if (indulgence.formatCraving) {
        for (var fmtName in indulgence.formatCraving) {
          var fmtPct = indulgence.formatCraving[fmtName];
          formatHtml +=
            '<div class="indulgence-chip">' +
              '<span class="fmt-title">' + fmtName + '</span>' +
              '<span class="fmt-pct">' + fmtPct + '% Craving</span>' +
            '</div>';
        }
      }

      var promptSetupHtml = '';
      if (!isFollowersSet) {
        promptSetupHtml =
          '<div class="form-card-box highlight-card" style="border: 2px solid var(--primary); margin-bottom: var(--space-6);">' +
            '<h3>Welcome! Set Your Follower Count</h3>' +
            '<p style="font-size:13px; color:var(--text-dim); margin-bottom:12px;">Please enter your current total followers for <strong>' + currentMonthKey + '</strong> so ContentOS can calculate exact reach predictions for your posts.</p>' +
            '<div class="form-row">' +
              '<div class="form-group">' +
                '<label class="form-label">Current Total Followers *</label>' +
                '<input type="number" id="bannerFollowerInput" class="form-input" placeholder="e.g. 5000" />' +
              '</div>' +
              '<div class="form-group" style="display:flex; align-items:flex-end;">' +
                '<button id="saveBannerFollowersBtn" class="btn btn-primary btn-full">Save & Calculate Predictions</button>' +
              '</div>' +
            '</div>' +
          '</div>';
      }

      container.innerHTML =
        '<div class="page-container">' +
          promptSetupHtml +
          '<div class="page-header flex-between">' +
            '<div>' +
              '<h1 class="page-title">Dashboard</h1>' +
              '<p class="page-subtitle">Monthly followers tracking, day-of-week niche predictions, and post log performance analytics.</p>' +
            '</div>' +
            '<div class="ig-sync-box">' +
              '<button id="updateFollowersBtn" class="btn btn-primary btn-sm">Update Monthly Followers</button>' +
            '</div>' +
          '</div>' +

          /* Monthly Followers Quick Update Box */
          '<div id="followersConfigPanel" class="form-card-box" style="display:none; margin-bottom: var(--space-6);">' +
            '<h3>Update Monthly Followers Record</h3>' +
            '<p style="margin-bottom:12px; font-size:13px; color:var(--text-dim);">Enter your follower count for <strong>' + currentMonthKey + '</strong>. All indulgence metrics and predictions will recalculate automatically.</p>' +
            '<div class="form-row">' +
              '<div class="form-group">' +
                '<label class="form-label">Month & Year</label>' +
                '<input type="text" id="followerMonthInput" class="form-input" value="' + currentMonthKey + '" readonly />' +
              '</div>' +
              '<div class="form-group">' +
                '<label class="form-label">Total Followers *</label>' +
                '<input type="number" id="followerCountInput" class="form-input" placeholder="e.g. 15000" value="' + followers + '" />' +
              '</div>' +
            '</div>' +
            '<div class="form-actions">' +
              '<button id="saveFollowersBtn" class="btn btn-primary btn-sm">Save Followers Count</button>' +
            '</div>' +
          '</div>' +

          /* Key Metrics Row */
          '<div class="stats-row">' +
            '<div class="stat-card highlight-card">' +
              '<span class="stat-label">Followers (' + currentMonthKey + ')</span>' +
              '<span class="stat-number">' + (isFollowersSet ? followers.toLocaleString() : 'Not Set') + '</span>' +
              '<span class="stat-growth">' + (isFollowersSet ? 'Tracked Monthly' : 'Action Required') + '</span>' +
            '</div>' +
            '<div class="stat-card">' +
              '<span class="stat-label">Audience Indulgence Index</span>' +
              '<span class="stat-number">' + indulgence.indulgenceScore + '%</span>' +
              '<span class="stat-sublabel">' + indulgence.level + '</span>' +
            '</div>' +
            '<div class="stat-card">' +
              '<span class="stat-label">Total Logged Posts</span>' +
              '<span class="stat-number">' + stats.totalPosts + '</span>' +
              '<span class="stat-sublabel">Average Eng: ' + stats.avgEngagement + '%</span>' +
            '</div>' +
          '</div>' +

          /* Day-of-Week 7-Day Niche Predictions Grid */
          '<div class="section-container">' +
            '<h2 class="section-title">Day-of-Week Niche & Time Predictions (Mon - Sun)</h2>' +
            '<p class="page-subtitle" style="margin-top:-8px; margin-bottom:16px;">Specific time, format, and niche predictions for each day based on past post performance.</p>' +
            '<div class="weekly-predictions-grid">' + weeklyGridHtml + '</div>' +
          '</div>' +

          /* Performance Graphs Section */
          '<div class="section-container">' +
            '<h2 class="section-title">Reach Trajectory & Format Graphs</h2>' +
            '<p class="page-subtitle" style="margin-top:-8px; margin-bottom:16px;">Mathematical curve analysis of your logged posts.</p>' +
            '<div class="graphs-grid">' +
              trendChartSvg +
              formatChartSvg +
            '</div>' +
          '</div>' +

          /* Interactive Precision Post Predictor */
          '<div class="section-container">' +
            '<h2 class="section-title">Precision Post Performance Predictor</h2>' +
            '<p class="page-subtitle" style="margin-top:-8px; margin-bottom:16px;">Test candidate post titles and formats to calculate an exact AI prediction score before publishing.</p>' +
            '<div class="predictor-wrapper ideas-card-box">' +
              '<div class="predictor-form">' +
                '<div class="form-group">' +
                  '<label class="form-label">Draft Post Caption / Title Hook</label>' +
                  '<input type="text" id="predTitleInput" class="form-input" value="10 Minimalist Desk Setup Items That Doubled My Focus" placeholder="e.g. 5 Morning Habits That Saved Me 10 Hours A Week" />' +
                '</div>' +
                '<div class="form-row">' +
                  '<div class="form-group">' +
                    '<label class="form-label">Format</label>' +
                    '<select id="predFormatSelect" class="form-select">' +
                      '<option value="Reel">Reel (Short Video)</option>' +
                      '<option value="Carousel">Carousel (Multi-Slide)</option>' +
                      '<option value="Static">Single Image Static</option>' +
                    '</select>' +
                  '</div>' +
                  '<div class="form-group">' +
                    '<label class="form-label">Target Niche / Topic</label>' +
                    '<input type="text" id="predTopicInput" class="form-input" value="Productivity Systems" />' +
                  '</div>' +
                '</div>' +
              '</div>' +
              '<div id="predResultBox" class="predictor-result-box">' +
                '<div class="pred-score-badge">' +
                  '<span class="score-num" id="predScoreVal">' + initialPred.score + '</span>' +
                  '<span class="score-label">Viral Index / 100</span>' +
                '</div>' +
                '<div class="pred-details">' +
                  '<div class="pred-metric"><span>Est. Reach:</span> <strong id="predReachVal">' + initialPred.predictedReach + '</strong></div>' +
                  '<div class="pred-metric"><span>Est. Engagement Rate:</span> <strong id="predEngVal">' + initialPred.predictedEngRate + '</strong></div>' +
                  '<div class="pred-tips" id="predTipsBox">' + initialPred.tips.join('<br>') + '</div>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +

          /* Follower Indulgence Breakdown */
          '<div class="section-container">' +
            '<h2 class="section-title">Follower Indulgence & Craving Matrix</h2>' +
            '<div class="indulgence-grid">' +
              '<div class="ideas-card-box">' +
                '<h3 class="box-subtitle">Topic Indulgence Breakdown</h3>' +
                '<p style="font-size:13px; color:var(--text-dim); margin-bottom:16px;">Topics your followers engage with and consume most heavily.</p>' +
                nicheHtml +
              '</div>' +
              '<div class="ideas-card-box">' +
                '<h3 class="box-subtitle">Format Craving</h3>' +
                '<p style="font-size:13px; color:var(--text-dim); margin-bottom:16px;">What content formats your followers demand right now.</p>' +
                '<div class="format-craving-container">' + formatHtml + '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';

      // Event Listeners
      var saveBannerFollowersBtn = document.getElementById('saveBannerFollowersBtn');
      var bannerFollowerInput = document.getElementById('bannerFollowerInput');
      if (saveBannerFollowersBtn && bannerFollowerInput) {
        saveBannerFollowersBtn.addEventListener('click', function () {
          var val = Number(bannerFollowerInput.value);
          if (val > 0) {
            App.followersStore.setMonthlyFollowers(val);
            self.renderDashboardView(container);
          }
        });
      }

      var updateFollowersBtn = document.getElementById('updateFollowersBtn');
      var followersPanel = document.getElementById('followersConfigPanel');
      if (updateFollowersBtn && followersPanel) {
        updateFollowersBtn.addEventListener('click', function () {
          followersPanel.style.display = followersPanel.style.display === 'none' ? 'block' : 'none';
        });
      }

      var saveFollowersBtn = document.getElementById('saveFollowersBtn');
      var followerCountInput = document.getElementById('followerCountInput');
      if (saveFollowersBtn && followerCountInput) {
        saveFollowersBtn.addEventListener('click', function () {
          var val = Number(followerCountInput.value) || 10000;
          App.followersStore.setMonthlyFollowers(val);
          self.renderDashboardView(container);
        });
      }

      // Predictor Input Event Listeners
      var predTitleInput = document.getElementById('predTitleInput');
      var predFormatSelect = document.getElementById('predFormatSelect');
      var predTopicInput = document.getElementById('predTopicInput');

      var updatePredictor = function () {
        var pTitle = predTitleInput ? predTitleInput.value : '';
        var pFmt = predFormatSelect ? predFormatSelect.value : 'Reel';
        var pTopic = predTopicInput ? predTopicInput.value : 'Productivity';

        var pred = App.analyticsEngine.predictPostPerformance(pTitle, pFmt, pTopic);

        var scoreEl = document.getElementById('predScoreVal');
        var reachEl = document.getElementById('predReachVal');
        var engEl = document.getElementById('predEngVal');
        var tipsEl = document.getElementById('predTipsBox');

        if (scoreEl) scoreEl.textContent = pred.score;
        if (reachEl) reachEl.textContent = pred.predictedReach;
        if (engEl) engEl.textContent = pred.predictedEngRate;
        if (tipsEl) tipsEl.innerHTML = pred.tips.join('<br>');
      };

      if (predTitleInput) predTitleInput.addEventListener('input', updatePredictor);
      if (predFormatSelect) predFormatSelect.addEventListener('change', updatePredictor);
      if (predTopicInput) predTopicInput.addEventListener('input', updatePredictor);
    },

    // 3. POST LOG VIEW
    renderPostsView: function (container) {
      var self = this;
      editingPostId = null;

      container.innerHTML =
        '<div class="page-container">' +
          '<div class="page-header flex-between">' +
            '<div>' +
              '<h1 class="page-title">Post Log</h1>' +
              '<p class="page-subtitle">Log your posts and track interactions.</p>' +
            '</div>' +
            '<button id="toggleFormBtn" class="btn btn-primary">+ Log New Post</button>' +
          '</div>' +
          '<div id="postFormContainer" style="display:none;" class="form-card-box"></div>' +
          '<div id="postsListContainer" class="posts-list"></div>' +
        '</div>';

      var toggleBtn = document.getElementById('toggleFormBtn');
      var formContainer = document.getElementById('postFormContainer');

      toggleBtn.addEventListener('click', function () {
        if (formContainer.style.display === 'none') {
          self.renderPostForm(formContainer, null);
          formContainer.style.display = 'block';
          toggleBtn.textContent = 'Close Form';
        } else {
          formContainer.style.display = 'none';
          toggleBtn.textContent = '+ Log New Post';
        }
      });

      this.renderPostsList();
    },

    renderPostForm: function (formContainer, postToEdit) {
      var self = this;
      editingPostId = postToEdit ? postToEdit.id : null;
      var today = new Date().toISOString().split('T')[0];

      formContainer.innerHTML =
        '<h3>' + (postToEdit ? 'Edit Post' : 'Log New Post') + '</h3>' +
        '<form id="postForm" novalidate>' +
          '<div class="form-group">' +
            '<label class="form-label">Title / Caption Snippet *</label>' +
            '<input type="text" id="postTitle" class="form-input" value="' + (postToEdit ? postToEdit.title : '') + '" placeholder="e.g. Morning routine reset" />' +
            '<div id="titleError" class="form-error"></div>' +
          '</div>' +
          '<div class="form-row">' +
            '<div class="form-group">' +
              '<label class="form-label">Format *</label>' +
              '<select id="postFormat" class="form-select">' +
                '<option value="Reel"' + (postToEdit && postToEdit.format === 'Reel' ? ' selected' : '') + '>Reel</option>' +
                '<option value="Carousel"' + (postToEdit && postToEdit.format === 'Carousel' ? ' selected' : '') + '>Carousel</option>' +
                '<option value="Static"' + (postToEdit && postToEdit.format === 'Static' ? ' selected' : '') + '>Static</option>' +
                '<option value="Story"' + (postToEdit && postToEdit.format === 'Story' ? ' selected' : '') + '>Story</option>' +
              '</select>' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label">Topic Keyword</label>' +
              '<input type="text" id="postTopic" class="form-input" value="' + (postToEdit ? postToEdit.topic : '') + '" placeholder="e.g. Productivity" />' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label">Date Posted *</label>' +
              '<input type="date" id="postDate" class="form-input" value="' + (postToEdit ? postToEdit.date : today) + '" />' +
              '<div id="dateError" class="form-error"></div>' +
            '</div>' +
          '</div>' +
          '<div class="form-row">' +
            '<div class="form-group">' +
              '<label class="form-label">Likes *</label>' +
              '<input type="number" id="postLikes" class="form-input" min="0" value="' + (postToEdit ? postToEdit.likes : '0') + '" />' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label">Comments *</label>' +
              '<input type="number" id="postComments" class="form-input" min="0" value="' + (postToEdit ? postToEdit.comments : '0') + '" />' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label">Shares *</label>' +
              '<input type="number" id="postShares" class="form-input" min="0" value="' + (postToEdit ? postToEdit.shares : '0') + '" />' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label">Reach *</label>' +
              '<input type="number" id="postReach" class="form-input" min="1" value="' + (postToEdit ? postToEdit.reach : '100') + '" />' +
            '</div>' +
          '</div>' +
          '<div class="form-actions">' +
            '<button type="button" id="cancelFormBtn" class="btn btn-secondary">Cancel</button>' +
            '<button type="submit" class="btn btn-primary">' + (postToEdit ? 'Update Post' : 'Save Post') + '</button>' +
          '</div>' +
        '</form>';

      var form = document.getElementById('postForm');
      var cancelBtn = document.getElementById('cancelFormBtn');

      cancelBtn.addEventListener('click', function () {
        formContainer.style.display = 'none';
        var toggleBtn = document.getElementById('toggleFormBtn');
        if (toggleBtn) toggleBtn.textContent = '+ Log New Post';
      });

      form.addEventListener('submit', function (e) {
        e.preventDefault();

        var titleVal = document.getElementById('postTitle').value;
        var dateVal = document.getElementById('postDate').value;

        var tRes = App.validators.required(titleVal, 'Title');
        var dRes = App.validators.required(dateVal, 'Date');

        if (!tRes.valid) {
          document.getElementById('titleError').textContent = tRes.error;
          document.getElementById('titleError').style.display = 'block';
          return;
        } else {
          document.getElementById('titleError').style.display = 'none';
        }

        if (!dRes.valid) {
          document.getElementById('dateError').textContent = dRes.error;
          document.getElementById('dateError').style.display = 'block';
          return;
        } else {
          document.getElementById('dateError').style.display = 'none';
        }

        var postData = {
          title: titleVal,
          format: document.getElementById('postFormat').value,
          topic: document.getElementById('postTopic').value,
          date: dateVal,
          likes: document.getElementById('postLikes').value,
          comments: document.getElementById('postComments').value,
          shares: document.getElementById('postShares').value,
          reach: document.getElementById('postReach').value
        };

        if (editingPostId) {
          App.postsStore.update(editingPostId, postData);
        } else {
          App.postsStore.add(postData);
        }

        formContainer.style.display = 'none';
        var toggleBtn = document.getElementById('toggleFormBtn');
        if (toggleBtn) toggleBtn.textContent = '+ Log New Post';

        self.renderPostsList();
      });
    },

    renderPostsList: function () {
      var listContainer = document.getElementById('postsListContainer');
      if (!listContainer) return;

      var posts = App.postsStore.getAll();
      if (posts.length === 0) {
        listContainer.innerHTML =
          '<div class="empty-state">' +
            '<p>No posts logged yet. Click "+ Log New Post" to add your first post.</p>' +
          '</div>';
        return;
      }

      var html = '';
      for (var i = 0; i < posts.length; i++) {
        var p = posts[i];
        var totalInteractions = (Number(p.likes) || 0) + (Number(p.comments) || 0) + (Number(p.shares) || 0);
        var engRate = Number(p.reach) > 0 ? ((totalInteractions / Number(p.reach)) * 100).toFixed(1) : '0.0';

        html +=
          '<div class="post-card" id="card_' + p.id + '">' +
            '<div class="post-header">' +
              '<span class="badge badge-' + p.format.toLowerCase() + '">' + p.format + '</span>' +
              '<h3 class="post-title">' + p.title + '</h3>' +
              '<span class="post-date">' + p.date + '</span>' +
            '</div>' +
            '<div class="post-metrics">' +
              '<span class="metric-chip">Likes: ' + p.likes + '</span>' +
              '<span class="metric-chip">Comments: ' + p.comments + '</span>' +
              '<span class="metric-chip">Shares: ' + p.shares + '</span>' +
              '<span class="metric-chip">Reach: ' + p.reach + '</span>' +
              '<span class="metric-chip highlight">Engagement: ' + engRate + '%</span>' +
            '</div>' +
            '<div class="post-actions">' +
              '<button class="btn btn-secondary btn-sm edit-btn" data-id="' + p.id + '">Edit</button>' +
              '<button class="btn btn-danger btn-sm del-btn" data-id="' + p.id + '">Delete</button>' +
            '</div>' +
          '</div>';
      }

      listContainer.innerHTML = html;

      var self = this;
      var editBtns = listContainer.querySelectorAll('.edit-btn');
      editBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          var posts = App.postsStore.getAll();
          var target = posts.find(function (item) { return item.id === id; });
          if (target) {
            var formContainer = document.getElementById('postFormContainer');
            self.renderPostForm(formContainer, target);
            formContainer.style.display = 'block';
            var toggleBtn = document.getElementById('toggleFormBtn');
            if (toggleBtn) toggleBtn.textContent = 'Close Form';
          }
        });
      });

      var delBtns = listContainer.querySelectorAll('.del-btn');
      delBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          App.postsStore.remove(id);
          self.renderPostsList();
        });
      });
    },

    // 4. IDEAS VIEW
    renderIdeasView: function (container) {
      var self = this;
      var profile = App.storage.get(App.storage.getUserKey('contentos:profile'), null);
      var niche = profile ? profile.niche : 'Lifestyle';

      container.innerHTML =
        '<div class="page-container">' +
          '<div class="page-header">' +
            '<h1 class="page-title">Content Idea Generator</h1>' +
            '<p class="page-subtitle">Combines niche phrase templates with a fetched advice quote.</p>' +
          '</div>' +
          '<div class="ideas-card-box">' +
            '<p>Click the button below to generate a new content hook for your niche (<strong>' + niche + '</strong>).</p>' +
            '<button id="generateIdeaBtn" class="btn btn-primary" style="margin-top:16px;">Generate Idea</button>' +
            '<div id="ideaResultSlot" style="margin-top:24px;"></div>' +
          '</div>' +
        '</div>';

      var btn = document.getElementById('generateIdeaBtn');
      var slot = document.getElementById('ideaResultSlot');

      btn.addEventListener('click', function () {
        self.fetchAndRenderIdea(btn, slot, niche);
      });
    },

    fetchAndRenderIdea: async function (btn, slot, niche) {
      btn.disabled = true;
      btn.textContent = 'Loading idea...';
      slot.innerHTML = '<div class="loading-spinner">Fetching fresh advice quote...</div>';

      var res = await App.ideaEngine.generateIdea(niche);

      btn.disabled = false;
      btn.textContent = 'Generate Idea';

      if (res.success) {
        slot.innerHTML =
          '<div class="idea-result-card">' +
            '<span class="badge badge-purple">Generated Hook</span>' +
            '<p class="idea-hook-text">' + res.hook + '</p>' +
          '</div>';
      } else {
        slot.innerHTML =
          '<div class="error-banner">' +
            '<p>' + res.error + '</p>' +
            '<button id="retryIdeaBtn" class="btn btn-secondary btn-sm" style="margin-top:8px;">Retry</button>' +
          '</div>';

        var retryBtn = document.getElementById('retryIdeaBtn');
        if (retryBtn) {
          var self = this;
          retryBtn.addEventListener('click', function () {
            self.fetchAndRenderIdea(btn, slot, niche);
          });
        }
      }
    }
  };
})(window.ContentOS);
